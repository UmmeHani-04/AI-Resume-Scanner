import jwt from 'jsonwebtoken'
const JWT_SECRET = process.env.JWT_SECRET || 'talentradar_super_secret_key_2026'

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : null
  if (!token) return res.status(401).json({ message: 'Authentication required' })
  try {
    req.user = jwt.verify(token, JWT_SECRET)
    next()
  } catch {
    return res.status(401).json({ message: 'Invalid or expired token' })
  }
}
export function requireRole(role) { return (req,res,next) => req.user?.role === role ? next() : res.status(403).json({message:'Forbidden'}) }
